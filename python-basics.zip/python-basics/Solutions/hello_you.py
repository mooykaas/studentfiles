def main():
    your_name = input("What is your name? ")
    print("Hello, ", your_name, "!", sep="")

main()